--auf Spiegel
ALTER DATABASE <database_name> SET PARTNER FORCE_SERVICE_ALLOW_DATA_LOSS

--Eventuell nicht synchronisiert
--