SELECT name, mirroring_role_desc 
FROM sys.databases WHERE name = N'AdventureWorks';
GO